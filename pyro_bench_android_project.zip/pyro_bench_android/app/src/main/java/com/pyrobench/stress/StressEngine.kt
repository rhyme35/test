package com.pyrobench.stress

import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

class StressEngine {

    private val running = AtomicBoolean(false)
    private val opsCounter = AtomicLong(0L)
    private val workers = mutableListOf<Thread>()
    private val directBuffers = mutableListOf<ByteBuffer>()
    private var ramThread: Thread? = null

    @Volatile
    var allocatedMb: Int = 0
        private set

    fun isRunning(): Boolean = running.get()

    fun drainOps(): Long = opsCounter.getAndSet(0L)

    fun start(
        threadCount: Int,
        targetRamMb: Int,
        enableRamChurn: Boolean,
        onLog: (String) -> Unit
    ) {
        if (!running.compareAndSet(false, true)) return
        opsCounter.set(0L)
        workers.clear()

        // 1. CPU Multi-Thread Workers
        for (i in 0 until threadCount) {
            val worker = Thread({
                var localAcc = 1.0001 + i * 0.01
                var hash0 = 0x67452301 xor i
                var hash1 = -0x10325477
                while (running.get()) {
                    for (k in 0 until 8000) {
                        val x = (k * 0.001) + localAcc
                        localAcc = sin(x) * cos(x) + tan(x * 0.25) * sqrt(kotlin.math.abs(x) + 1.0)
                        hash0 = (hash0 xor (k shl 3)) + ((hash1 ushr 2) xor (k and 0xFF))
                        hash1 = (hash1 xor (hash0 ushr 5)) + ((hash0 shl 4) xor (k and 0x0F))
                    }
                    // Prevent dead-code elimination
                    if (localAcc == Double.NaN && hash1 == 0) {
                        opsCounter.addAndGet(1L)
                    }
                    opsCounter.addAndGet(8000L)
                }
            }, "PyroCPU-$i")
            worker.priority = Thread.MAX_PRIORITY
            worker.start()
            workers.add(worker)
        }
        onLog("Spawned $threadCount high-priority CPU worker threads.")

        // 2. Native Direct RAM Allocation & Memory Bus Churn
        if (targetRamMb > 0) {
            ramThread = Thread({
                val chunkMb = 32
                val blocks = targetRamMb / chunkMb
                var totalAllocated = 0
                synchronized(directBuffers) {
                    directBuffers.clear()
                }

                for (b in 0 until blocks) {
                    if (!running.get()) break
                    try {
                        val buf = ByteBuffer.allocateDirect(chunkMb * 1024 * 1024)
                        // Touch every 4KB page so Linux kernel commits physical RAM
                        var pos = 0
                        val cap = buf.capacity()
                        while (pos < cap) {
                            buf.put(pos, ((b xor pos) and 0xFF).toByte())
                            pos += 4096
                        }
                        synchronized(directBuffers) {
                            directBuffers.add(buf)
                        }
                        totalAllocated += chunkMb
                        allocatedMb = totalAllocated
                    } catch (oom: OutOfMemoryError) {
                        onLog("RAM limit reached at ${totalAllocated} MB (OS safety ceiling).")
                        break
                    }
                }
                onLog("Committed ${allocatedMb} MB native direct RAM buffers.")

                var pass = 1
                while (running.get() && enableRamChurn) {
                    val snapshot = synchronized(directBuffers) { directBuffers.toList() }
                    val marker = (pass++ and 0xFF).toByte()
                    for (buf in snapshot) {
                        if (!running.get()) break
                        var pos = 0
                        val cap = buf.capacity()
                        while (pos < cap) {
                            buf.put(pos, (buf.get(pos).toInt() xor marker.toInt()).toByte())
                            pos += 4096
                        }
                    }
                    try {
                        Thread.sleep(60)
                    } catch (_: InterruptedException) {
                        break
                    }
                }
            }, "PyroRAM")
            ramThread?.start()
        }
    }

    fun stop(onLog: (String) -> Unit) {
        if (!running.compareAndSet(true, false)) return
        workers.forEach { it.interrupt() }
        workers.clear()
        ramThread?.interrupt()
        ramThread = null
        synchronized(directBuffers) {
            directBuffers.clear()
        }
        allocatedMb = 0
        System.gc()
        onLog("All stress workers halted and native RAM released.")
    }
}
