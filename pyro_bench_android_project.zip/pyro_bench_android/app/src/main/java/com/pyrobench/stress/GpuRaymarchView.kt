package com.pyrobench.stress

import android.content.Context
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class GpuRaymarchView(context: Context) : GLSurfaceView(context) {

    private val renderer: RaymarchRenderer

    init {
        setEGLContextClientVersion(2)
        renderer = RaymarchRenderer()
        setRenderer(renderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun setBurnActive(active: Boolean) {
        renderer.active = active
        renderMode = if (active) RENDERMODE_CONTINUOUSLY else RENDERMODE_WHEN_DIRTY
        if (!active) {
            requestRender()
        }
    }

    fun getCurrentFps(): Int = renderer.fps

    private class RaymarchRenderer : Renderer {
        @Volatile
        var active: Boolean = false

        @Volatile
        var fps: Int = 0

        private var programId = 0
        private var timeLoc = 0
        private var resLoc = 0
        private var width = 1
        private var height = 1
        private var startTimeNs = System.nanoTime()
        private var frames = 0
        private var lastFpsNs = System.nanoTime()

        private val quadBuffer: FloatBuffer = ByteBuffer.allocateDirect(6 * 2 * 4)
            .order(ByteOrder.nativeOrder())
            .asFloatBuffer()
            .apply {
                put(
                    floatArrayOf(
                        -1f, -1f,
                         1f, -1f,
                        -1f,  1f,
                        -1f,  1f,
                         1f, -1f,
                         1f,  1f
                    )
                )
                position(0)
            }

        private val vertexShaderCode = """
            attribute vec2 aPos;
            void main() {
                gl_Position = vec4(aPos, 0.0, 1.0);
            }
        """.trimIndent()

        private val fragmentShaderCode = """
            precision highp float;
            uniform vec2 uRes;
            uniform float uTime;

            float map(vec3 p) {
                vec3 q = mod(p + 2.0, 4.0) - 2.0;
                float sphere = length(q) - 0.9;
                float twist = sin(p.x * 2.5 + uTime * 3.0) * cos(p.y * 2.5) * sin(p.z * 2.5);
                return sphere + twist * 0.28;
            }

            void main() {
                vec2 uv = (gl_FragCoord.xy - 0.5 * uRes) / min(uRes.x, uRes.y);
                vec3 ro = vec3(0.0, 0.0, -3.0 + sin(uTime * 0.6));
                vec3 rd = normalize(vec3(uv, 1.2));
                float totalDist = 0.0;
                float steps = 0.0;
                for (int i = 0; i < 64; i++) {
                    vec3 p = ro + rd * totalDist;
                    float d = map(p);
                    totalDist += d * 0.5;
                    steps = float(i);
                    if (d < 0.005 || totalDist > 20.0) break;
                }
                float t = steps / 64.0;
                vec3 col = vec3(t * 1.6, t * t * 0.85, t * t * t * 1.9);
                if (totalDist > 20.0) col = vec3(0.04, 0.02, 0.07);
                gl_FragColor = vec4(col, 1.0);
            }
        """.trimIndent()

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
            val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)
            programId = GLES20.glCreateProgram().also {
                GLES20.glAttachShader(it, vs)
                GLES20.glAttachShader(it, fs)
                GLES20.glLinkProgram(it)
            }
            timeLoc = GLES20.glGetUniformLocation(programId, "uTime")
            resLoc = GLES20.glGetUniformLocation(programId, "uRes")
        }

        override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
            width = w.coerceAtLeast(1)
            height = h.coerceAtLeast(1)
            GLES20.glViewport(0, 0, width, height)
        }

        override fun onDrawFrame(gl: GL10?) {
            if (!active) {
                GLES20.glClearColor(0.04f, 0.05f, 0.08f, 1.0f)
                GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
                fps = 0
                return
            }

            GLES20.glUseProgram(programId)
            val posHandle = GLES20.glGetAttribLocation(programId, "aPos")
            GLES20.glEnableVertexAttribArray(posHandle)
            GLES20.glVertexAttribPointer(posHandle, 2, GLES20.GL_FLOAT, false, 0, quadBuffer)

            val elapsedSec = (System.nanoTime() - startTimeNs) / 1_000_000_000f
            GLES20.glUniform1f(timeLoc, elapsedSec)
            GLES20.glUniform2f(resLoc, width.toFloat(), height.toFloat())
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            GLES20.glDisableVertexAttribArray(posHandle)

            frames++
            val now = System.nanoTime()
            val dt = now - lastFpsNs
            if (dt >= 1_000_000_000L) {
                fps = ((frames * 1_000_000_000L) / dt).toInt()
                frames = 0
                lastFpsNs = now
            }
        }

        private fun compileShader(type: Int, src: String): Int {
            return GLES20.glCreateShader(type).also { shader ->
                GLES20.glShaderSource(shader, src)
                GLES20.glCompileShader(shader)
            }
        }
    }
}
