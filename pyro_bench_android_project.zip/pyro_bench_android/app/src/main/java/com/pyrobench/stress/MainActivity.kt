package com.pyrobench.stress

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val engine = StressEngine()
    private val uiHandler = Handler(Looper.getMainLooper())
    private lateinit var gpuView: GpuRaymarchView

    private lateinit var tvDeviceInfo: TextView
    private lateinit var tvCpuOps: TextView
    private lateinit var tvThrottle: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvThermalStatus: TextView
    private lateinit var tvRamAllocated: TextView
    private lateinit var tvSystemRam: TextView
    private lateinit var tvGpuFps: TextView
    private lateinit var tvElapsed: TextView
    private lateinit var tvThreadsLabel: TextView
    private lateinit var tvRamLabel: TextView
    private lateinit var tvLog: TextView
    private lateinit var seekThreads: SeekBar
    private lateinit var seekRam: SeekBar
    private lateinit var cbRamChurn: CheckBox
    private lateinit var cbGpuShader: CheckBox
    private lateinit var btnToggleStress: Button

    private var selectedThreads = Runtime.getRuntime().availableProcessors().coerceAtLeast(1)
    private var selectedRamMb = 1024
    private var peakOpsPerSec = 0L
    private var elapsedSeconds = 0
    private val logLines = ArrayDeque<String>(12)

    private val telemetryTick = object : Runnable {
        override fun run() {
            updateTelemetry()
            uiHandler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvDeviceInfo = findViewById(R.id.tvDeviceInfo)
        tvCpuOps = findViewById(R.id.tvCpuOps)
        tvThrottle = findViewById(R.id.tvThrottle)
        tvTemp = findViewById(R.id.tvTemp)
        tvThermalStatus = findViewById(R.id.tvThermalStatus)
        tvRamAllocated = findViewById(R.id.tvRamAllocated)
        tvSystemRam = findViewById(R.id.tvSystemRam)
        tvGpuFps = findViewById(R.id.tvGpuFps)
        tvElapsed = findViewById(R.id.tvElapsed)
        tvThreadsLabel = findViewById(R.id.tvThreadsLabel)
        tvRamLabel = findViewById(R.id.tvRamLabel)
        tvLog = findViewById(R.id.tvLog)
        seekThreads = findViewById(R.id.seekThreads)
        seekRam = findViewById(R.id.seekRam)
        cbRamChurn = findViewById(R.id.cbRamChurn)
        cbGpuShader = findViewById(R.id.cbGpuShader)
        btnToggleStress = findViewById(R.id.btnToggleStress)

        gpuView = GpuRaymarchView(this)
        findViewById<FrameLayout>(R.id.gpuContainer).addView(gpuView)

        val cores = Runtime.getRuntime().availableProcessors()
        tvDeviceInfo.text = "${Build.MANUFACTURER} ${Build.MODEL} • $cores CPU Cores • Android ${Build.VERSION.RELEASE}"

        selectedThreads = cores.coerceIn(1, 16)
        seekThreads.progress = selectedThreads - 1
        tvThreadsLabel.text = "CPU Worker Threads: $selectedThreads"

        seekThreads.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedThreads = progress + 1
                tvThreadsLabel.text = "CPU Worker Threads: $selectedThreads"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        // 0 to 4096 MB in 128 MB increments (32 * 128 = 4096)
        seekRam.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                selectedRamMb = progress * 128
                tvRamLabel.text = "Target Direct RAM Buffer: $selectedRamMb MB"
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })

        btnToggleStress.setOnClickListener {
            if (engine.isRunning()) {
                stopStress()
            } else {
                startStress()
            }
        }

        uiHandler.post(telemetryTick)
    }

    private fun startStress() {
        peakOpsPerSec = 0L
        elapsedSeconds = 0
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btnToggleStress.text = "ABORT STRESS TEST"
        appendLog("Starting stress: $selectedThreads threads, $selectedRamMb MB RAM, GPU=${cbGpuShader.isChecked}")

        engine.start(
            threadCount = selectedThreads,
            targetRamMb = selectedRamMb,
            enableRamChurn = cbRamChurn.isChecked
        ) { msg -> runOnUiThread { appendLog(msg) } }

        gpuView.setBurnActive(cbGpuShader.isChecked)
    }

    private fun stopStress() {
        engine.stop { msg -> runOnUiThread { appendLog(msg) } }
        gpuView.setBurnActive(false)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        btnToggleStress.text = "ENGAGE MAXIMUM STRESS TEST"
        tvCpuOps.text = "0.00 Mops/s"
        tvGpuFps.text = "IDLE"
    }

    private fun updateTelemetry() {
        // Battery temperature (in tenths of a degree C)
        val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val rawTemp = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1) ?: -1
        if (rawTemp > 0) {
            tvTemp.text = String.format(Locale.US, "%.1f °C", rawTemp / 10.0)
        }

        // Android 10+ Thermal Status
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val label = when (pm.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "NOMINAL"
                PowerManager.THERMAL_STATUS_LIGHT -> "WARM (LIGHT)"
                PowerManager.THERMAL_STATUS_MODERATE -> "MODERATE"
                PowerManager.THERMAL_STATUS_SEVERE -> "SEVERE THROTTLE"
                PowerManager.THERMAL_STATUS_CRITICAL -> "CRITICAL"
                PowerManager.THERMAL_STATUS_EMERGENCY -> "EMERGENCY"
                else -> "UNKNOWN"
            }
            tvThermalStatus.text = "Thermal: $label"
        }

        // System RAM
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memInfo)
        val freeMb = memInfo.availMem / (1024 * 1024)
        val totalMb = memInfo.totalMem / (1024 * 1024)
        tvSystemRam.text = "Free: ${freeMb} / ${totalMb} MB"
        tvRamAllocated.text = "${engine.allocatedMb} MB"

        if (engine.isRunning()) {
            elapsedSeconds++
            tvElapsed.text = "Elapsed: ${elapsedSeconds}s"

            val ops = engine.drainOps()
            val mops = ops / 1_000_000.0
            tvCpuOps.text = String.format(Locale.US, "%.2f Mops/s", mops)

            if (ops > peakOpsPerSec) peakOpsPerSec = ops
            val eff = if (peakOpsPerSec > 0) ((ops * 100) / peakOpsPerSec).toInt().coerceIn(0, 100) else 100
            tvThrottle.text = "Efficiency: $eff%"

            tvGpuFps.text = if (cbGpuShader.isChecked) "${gpuView.getCurrentFps()} FPS" else "OFF"
        }
    }

    private fun appendLog(message: String) {
        val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        if (logLines.size >= 10) logLines.removeFirst()
        logLines.addLast("[$ts] $message")
        tvLog.text = logLines.joinToString("\n")
    }

    override fun onResume() {
        super.onResume()
        gpuView.onResume()
    }

    override fun onPause() {
        super.onPause()
        gpuView.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        uiHandler.removeCallbacks(telemetryTick)
        if (engine.isRunning()) {
            engine.stop {}
        }
    }
}
